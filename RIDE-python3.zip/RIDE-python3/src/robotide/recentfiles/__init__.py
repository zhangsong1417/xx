from .recentfiles import RecentFilesPlugin
