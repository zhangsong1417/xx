# This sits in the plugin directory but is not a plugin.
# This exists to test that such a thing won't cause the 
# plugin manager to throw an exception.
